using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using System.Globalization;

namespace ERP.Pages
{
    public class ReportsModel : PageModel
    {
        public string? ErrorMessage { get; set; }

        private readonly string _connStr =
            "Server=localhost\\SQLEXPRESS;Database=ERP_DB;Trusted_Connection=True;TrustServerCertificate=True;";

        public void OnGet() { }

        public IActionResult OnGetData()
        {
            try
            {
                using var conn = new SqlConnection(_connStr);
                conn.Open();

                // Siste 300 ordre (nyeste f�rst)
                string qOrdersList = @"
SELECT TOP 300
    o.OrderId,
    o.CreatedDate,
    o.Status,
    o.RedQty,
    o.BlackQty,
    o.TotalQty,
    o.StartedDate,
    o.FinishedDate,
    CASE
        WHEN o.StartedDate IS NOT NULL AND o.FinishedDate IS NOT NULL
            THEN DATEDIFF(SECOND, o.StartedDate, o.FinishedDate)
        WHEN o.StartedDate IS NOT NULL AND o.FinishedDate IS NULL AND o.Status='Running'
            THEN DATEDIFF(SECOND, o.StartedDate, GETDATE())
        ELSE NULL
    END AS DurationSeconds
FROM Orders o
ORDER BY o.CreatedDate DESC;";

                var orders = new List<object>();

                using (var cmd = new SqlCommand(qOrdersList, conn))
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        DateTime created = Convert.ToDateTime(r["CreatedDate"]);
                        DateTime? started = r["StartedDate"] == DBNull.Value ? null : (DateTime?)Convert.ToDateTime(r["StartedDate"]);
                        DateTime? finished = r["FinishedDate"] == DBNull.Value ? null : (DateTime?)Convert.ToDateTime(r["FinishedDate"]);

                        orders.Add(new
                        {
                            orderId = Convert.ToInt32(r["OrderId"]),
                            createdText = created.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture),
                            status = r["Status"].ToString() ?? "",
                            redQty = Convert.ToInt32(r["RedQty"]),
                            blackQty = Convert.ToInt32(r["BlackQty"]),
                            totalQty = Convert.ToInt32(r["TotalQty"]),
                            startedText = started?.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture),
                            finishedText = finished?.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture),
                            durationSeconds = r["DurationSeconds"] == DBNull.Value ? (int?)null : Convert.ToInt32(r["DurationSeconds"])
                        });
                    }
                }

                return new JsonResult(new { orders });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { error = ex.Message }) { StatusCode = 500 };
            }
        }
    }
}
