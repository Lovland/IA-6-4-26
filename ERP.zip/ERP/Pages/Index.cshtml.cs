using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace ERP.Pages
{
    public class IndexModel : PageModel
    {
        public string? ErrorMessage { get; set; }

        private readonly string _connStr =
            "Server=localhost\\SQLEXPRESS;Database=ERP_DB;Trusted_Connection=True;TrustServerCertificate=True;";

        public DashboardKpi Kpi { get; set; } = new();
        public List<OrderRow> LatestOrders { get; set; } = new();

        public void OnGet()
        {
            try
            {
                using var conn = new SqlConnection(_connStr);
                conn.Open();

                LoadKpi(conn);
                LoadLatestOrders(conn);
            }
            catch (Exception ex)
            {
                ErrorMessage = "Feil ved lasting av forsiden: " + ex.Message;
            }
        }

        private void LoadKpi(SqlConnection conn)
        {
            string sql = @"
SELECT
    (SELECT COUNT(*)
     FROM Orders
     WHERE Status = 'Finished') AS CompletedOrders,

    (SELECT COUNT(*)
     FROM Orders
     WHERE Status IN ('Pending', 'Active', 'Running')) AS ActivePendingOrders,

    (SELECT AVG(CAST(DATEDIFF(SECOND, StartedDate, FinishedDate) AS FLOAT))
     FROM Orders
     WHERE Status = 'Finished'
       AND StartedDate IS NOT NULL
       AND FinishedDate IS NOT NULL) AS AvgCycleSeconds,

    (SELECT AVG(CAST(ISNULL(QuantityProductFault, 0) AS FLOAT))
     FROM Orders
     WHERE Status = 'Finished') AS AvgQuantityProductFault;";

            using var cmd = new SqlCommand(sql, conn);
            using var r = cmd.ExecuteReader();

            if (r.Read())
            {
                Kpi.CompletedOrders = r["CompletedOrders"] == DBNull.Value ? 0 : Convert.ToInt32(r["CompletedOrders"]);
                Kpi.ActivePendingOrders = r["ActivePendingOrders"] == DBNull.Value ? 0 : Convert.ToInt32(r["ActivePendingOrders"]);
                Kpi.AvgCycleSeconds = r["AvgCycleSeconds"] == DBNull.Value ? null : Convert.ToDouble(r["AvgCycleSeconds"]);
                Kpi.AvgQuantityProductFault = r["AvgQuantityProductFault"] == DBNull.Value ? null : Convert.ToDouble(r["AvgQuantityProductFault"]);
            }
        }

        private void LoadLatestOrders(SqlConnection conn)
        {
            string sql = @"
SELECT TOP 10
    OrderId,
    Status,
    CreatedDate,
    StartedDate,
    FinishedDate,
    ISNULL(QuantityProductFault, 0) AS QuantityProductFault,
    ISNULL(TestPhase, '') AS TestPhase,
    CASE
        WHEN StartedDate IS NOT NULL AND FinishedDate IS NOT NULL
            THEN DATEDIFF(SECOND, StartedDate, FinishedDate)
        ELSE NULL
    END AS CycleSeconds
FROM Orders
ORDER BY OrderId DESC;";

            using var cmd = new SqlCommand(sql, conn);
            using var r = cmd.ExecuteReader();

            while (r.Read())
            {
                LatestOrders.Add(new OrderRow
                {
                    OrderId = Convert.ToInt32(r["OrderId"]),
                    Status = r["Status"]?.ToString() ?? "",
                    CreatedDate = Convert.ToDateTime(r["CreatedDate"]),
                    StartedDate = r["StartedDate"] == DBNull.Value ? null : Convert.ToDateTime(r["StartedDate"]),
                    FinishedDate = r["FinishedDate"] == DBNull.Value ? null : Convert.ToDateTime(r["FinishedDate"]),
                    QuantityProductFault = Convert.ToInt32(r["QuantityProductFault"]),
                    TestPhase = r["TestPhase"]?.ToString() ?? "",
                    CycleSeconds = r["CycleSeconds"] == DBNull.Value ? null : Convert.ToInt32(r["CycleSeconds"])
                });
            }
        }

        public string FormatDouble(double? value, int decimals)
        {
            if (!value.HasValue)
                return "-";

            return value.Value.ToString("F" + decimals)
                .Replace(",", "X")
                .Replace(".", ",")
                .Replace("X", ".");
        }

        public class DashboardKpi
        {
            public int CompletedOrders { get; set; }
            public int ActivePendingOrders { get; set; }
            public double? AvgCycleSeconds { get; set; }
            public double? AvgQuantityProductFault { get; set; }
        }

        public class OrderRow
        {
            public int OrderId { get; set; }
            public string Status { get; set; } = "";
            public DateTime CreatedDate { get; set; }
            public DateTime? StartedDate { get; set; }
            public DateTime? FinishedDate { get; set; }
            public int QuantityProductFault { get; set; }
            public string TestPhase { get; set; } = "";
            public int? CycleSeconds { get; set; }
        }
    }
}