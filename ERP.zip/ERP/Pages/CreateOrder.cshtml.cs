using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace ERP.Pages
{
    public class CreateOrderModel : PageModel
    {
        [BindProperty] public int RedQty { get; set; }
        [BindProperty] public int BlackQty { get; set; }
        [BindProperty] public string? TestPhase { get; set; }

        [BindProperty] public int[] CupWater { get; set; } = new int[12];

        public string? ErrorMessage { get; set; }
        public string? SuccessMessage { get; set; }

        private readonly string _connStr =
            "Server=localhost\\SQLEXPRESS;Database=ERP_DB;Trusted_Connection=True;TrustServerCertificate=True;";

        public void OnGet()
        {
            if (CupWater == null || CupWater.Length != 12)
                CupWater = new int[12];
        }

        public IActionResult OnPost()
        {
            if (RedQty < 0 || RedQty > 6)
            {
                ErrorMessage = "R�d (antall) m� v�re mellom 0 og 6.";
                return Page();
            }

            if (BlackQty < 0 || BlackQty > 6)
            {
                ErrorMessage = "Svart (antall) m� v�re mellom 0 og 6.";
                return Page();
            }

            if (string.IsNullOrWhiteSpace(TestPhase))
            {
                ErrorMessage = "Du m� velge testfase.";
                return Page();
            }

            if (TestPhase != "Before" && TestPhase != "After")
            {
                ErrorMessage = "Ugyldig testfase.";
                return Page();
            }

            int total = RedQty + BlackQty;

            if (total < 0 || total > 12)
            {
                ErrorMessage = "Total (r�d + svart) m� v�re mellom 0 og 12.";
                return Page();
            }

            if (CupWater == null || CupWater.Length != 12)
            {
                ErrorMessage = "CupWater mangler (m� v�re 12 verdier).";
                return Page();
            }

            for (int i = 0; i < 12; i++)
            {
                if (i < total)
                {
                    if (CupWater[i] < 0 || CupWater[i] > 100)
                    {
                        ErrorMessage = $"Cup {i + 1}: vann% m� v�re 0�100.";
                        return Page();
                    }
                }
                else
                {
                    CupWater[i] = 0;
                }
            }

            try
            {
                using var conn = new SqlConnection(_connStr);
                conn.Open();

                using var tx = conn.BeginTransaction();

                int orderId;
                string insertOrder = @"
INSERT INTO Orders (RedQty, BlackQty, TotalQty, Status, CreatedDate, QuantityProductFault, TestPhase)
OUTPUT INSERTED.OrderId
VALUES (@red, @black, @total, @status, @created, @QuantityProductFault, @testPhase);";

                using (var cmd = new SqlCommand(insertOrder, conn, tx))
                {
                    cmd.Parameters.AddWithValue("@red", RedQty);
                    cmd.Parameters.AddWithValue("@black", BlackQty);
                    cmd.Parameters.AddWithValue("@total", total);
                    cmd.Parameters.AddWithValue("@status", "Pending");
                    cmd.Parameters.AddWithValue("@created", DateTime.Now);
                    cmd.Parameters.AddWithValue("@QuantityProductFault", 0);
                    cmd.Parameters.AddWithValue("@testPhase", TestPhase);

                    orderId = (int)cmd.ExecuteScalar();
                }

                string insertCup = @"
INSERT INTO OrderCups (OrderId, CupNo, Color, WaterPercent)
VALUES (@orderId, @cupNo, @color, @water);";

                int cupNo = 1;

                for (int i = 0; i < RedQty; i++)
                {
                    using var cmd = new SqlCommand(insertCup, conn, tx);
                    cmd.Parameters.AddWithValue("@orderId", orderId);
                    cmd.Parameters.AddWithValue("@cupNo", cupNo);
                    cmd.Parameters.AddWithValue("@color", "Red");
                    cmd.Parameters.AddWithValue("@water", CupWater[cupNo - 1]);
                    cmd.ExecuteNonQuery();
                    cupNo++;
                }

                for (int i = 0; i < BlackQty; i++)
                {
                    using var cmd = new SqlCommand(insertCup, conn, tx);
                    cmd.Parameters.AddWithValue("@orderId", orderId);
                    cmd.Parameters.AddWithValue("@cupNo", cupNo);
                    cmd.Parameters.AddWithValue("@color", "Black");
                    cmd.Parameters.AddWithValue("@water", CupWater[cupNo - 1]);
                    cmd.ExecuteNonQuery();
                    cupNo++;
                }

                tx.Commit();

                RedQty = 0;
                BlackQty = 0;
                TestPhase = null;
                CupWater = new int[12];

                SuccessMessage = $"Ordre lagret! OrderId = {orderId}";
                return Page();
            }
            catch (Exception ex)
            {
                ErrorMessage = "SQL-feil: " + ex.Message;
                return Page();
            }
        }
    }
}