using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using System.Globalization;

namespace ERP.Pages
{
    public class AnalyseModel : PageModel
    {
        private const double CupWeightG = 14.61;
        private const double WeightAt100PercentG = 28.62;
        private const double NetWeightAt100PercentG = WeightAt100PercentG - CupWeightG;

        private readonly string _connStr =
            "Server=localhost\\SQLEXPRESS;Database=ERP_DB;Trusted_Connection=True;TrustServerCertificate=True;";

        [BindProperty(SupportsGet = true)]
        public string? SelectedPhase { get; set; }

        [BindProperty(SupportsGet = true)]
        public DateTime? FromDate { get; set; }

        [BindProperty(SupportsGet = true)]
        public DateTime? ToDate { get; set; }

        [BindProperty(SupportsGet = true)]
        public double Tolerance { get; set; } = 5.0;

        public int TotalOrders { get; set; }
        public int TotalCups { get; set; }
        public int TotalProduced { get; set; }
        public int TotalFaultProducts { get; set; }

        public double AvgCycleTime { get; set; }
        public double MinCycleTime { get; set; }
        public double MaxCycleTime { get; set; }

        public int QualityMeasurementCount { get; set; }
        public int AcceptedCount { get; set; }
        public double AvgWeightDifference { get; set; }
        public double MaxAbsWeightDifference { get; set; }
        public double MAE { get; set; }
        public double MAPE { get; set; }
        public double MSE { get; set; }
        public double RMSE { get; set; }
        public double AcceptanceRate { get; set; }

        public List<CupAnalysisRow> CupRows { get; set; } = new();
        public List<PhaseComparisonRow> PhaseComparisons { get; set; } = new();

        public List<string> CycleChartLabels { get; set; } = new();
        public List<double> CycleChartValues { get; set; } = new();

        public List<string> ErrorByCupChartLabels { get; set; } = new();
        public List<double> ErrorByCupChartValues { get; set; } = new();

        public string AvgCycleTimeFormatted => AvgCycleTime.ToString("N1", CultureInfo.InvariantCulture);
        public string MinCycleTimeFormatted => MinCycleTime.ToString("N1", CultureInfo.InvariantCulture);
        public string MaxCycleTimeFormatted => MaxCycleTime.ToString("N1", CultureInfo.InvariantCulture);

        public string AvgWeightDifferenceFormatted => AvgWeightDifference.ToString("N2", CultureInfo.InvariantCulture);
        public string MaxAbsWeightDifferenceFormatted => MaxAbsWeightDifference.ToString("N2", CultureInfo.InvariantCulture);
        public string MAEFormatted => MAE.ToString("N2", CultureInfo.InvariantCulture);
        public string MAPEFormatted => MAPE.ToString("N2", CultureInfo.InvariantCulture) + "%";
        public string MSEFormatted => MSE.ToString("N2", CultureInfo.InvariantCulture);
        public string RMSEFormatted => RMSE.ToString("N2", CultureInfo.InvariantCulture);
        public string AcceptanceRateFormatted => AcceptanceRate.ToString("N1", CultureInfo.InvariantCulture) + "%";

        public string CycleImprovementText
        {
            get
            {
                var before = PhaseComparisons.FirstOrDefault(x => x.TestPhase == "Before");
                var after = PhaseComparisons.FirstOrDefault(x => x.TestPhase == "After");

                if (before == null || after == null || before.AvgCycleTime <= 0)
                    return "-";

                var improvement = ((before.AvgCycleTime - after.AvgCycleTime) / before.AvgCycleTime) * 100.0;
                return improvement.ToString("N1", CultureInfo.InvariantCulture) + "%";
            }
        }

        public string MapeImprovementText
        {
            get
            {
                var before = PhaseComparisons.FirstOrDefault(x => x.TestPhase == "Before");
                var after = PhaseComparisons.FirstOrDefault(x => x.TestPhase == "After");

                if (before == null || after == null)
                    return "-";

                var improvement = before.MAPE - after.MAPE;
                return improvement.ToString("N2", CultureInfo.InvariantCulture) + " prosentpoeng";
            }
        }

        public void OnGet()
        {
            if (Tolerance < 0)
                Tolerance = 5.0;

            LoadAnalysis();
        }

        private void LoadAnalysis()
        {
            using var connection = new SqlConnection(_connStr);
            connection.Open();

            LoadCupRows(connection);
            CalculateSummary();
            CalculatePhaseComparison();
            BuildCharts();
        }

        private void LoadCupRows(SqlConnection connection)
        {
            var sql = @"
SELECT
    o.OrderId,
    o.CreatedDate,
    o.TestPhase,
    o.QuantityProduced,
    o.QuantityProductFault,
    oc.CupNo,
    oc.Color,
    oc.WaterPercent,
    oc.WeightDifference,
    oc.RealWeight,
    oc.TimeSpentMinutes
FROM OrderCups oc
INNER JOIN Orders o ON o.OrderId = oc.OrderId
WHERE o.Status = 'Finished'
";

            var filters = new List<string>();

            if (!string.IsNullOrWhiteSpace(SelectedPhase))
                filters.Add("o.TestPhase = @TestPhase");

            if (FromDate.HasValue)
                filters.Add("CAST(o.CreatedDate AS date) >= @FromDate");

            if (ToDate.HasValue)
                filters.Add("CAST(o.CreatedDate AS date) <= @ToDate");

            if (filters.Count > 0)
                sql += " AND " + string.Join(" AND ", filters);

            sql += " ORDER BY o.OrderId, oc.CupNo";

            using var cmd = new SqlCommand(sql, connection);

            if (!string.IsNullOrWhiteSpace(SelectedPhase))
                cmd.Parameters.AddWithValue("@TestPhase", SelectedPhase!);

            if (FromDate.HasValue)
                cmd.Parameters.AddWithValue("@FromDate", FromDate.Value.Date);

            if (ToDate.HasValue)
                cmd.Parameters.AddWithValue("@ToDate", ToDate.Value.Date);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var waterPercent = reader["WaterPercent"] == DBNull.Value ? 0 : Convert.ToDouble(reader["WaterPercent"]);
                var weightDifference = reader["WeightDifference"] == DBNull.Value ? (double?)null : Convert.ToDouble(reader["WeightDifference"]);
                var realWeight = reader["RealWeight"] == DBNull.Value ? (double?)null : Convert.ToDouble(reader["RealWeight"]);
                var timeSpentMinutes = reader["TimeSpentMinutes"] == DBNull.Value ? (decimal?)null : Convert.ToDecimal(reader["TimeSpentMinutes"]);

                var targetNetWeight = (waterPercent / 100.0) * NetWeightAt100PercentG;
                double? errorPercent = null;

                if (weightDifference.HasValue && realWeight.HasValue && realWeight.Value > CupWeightG)
                    errorPercent = Math.Abs(weightDifference.Value) / (realWeight.Value - CupWeightG) * 100.0;
                else if (weightDifference.HasValue && targetNetWeight > 0)
                    errorPercent = Math.Abs(weightDifference.Value) / targetNetWeight * 100.0;

                CupRows.Add(new CupAnalysisRow
                {
                    OrderId = Convert.ToInt32(reader["OrderId"]),
                    TestPhase = reader["TestPhase"]?.ToString() ?? "",
                    CreatedDate = reader["CreatedDate"] == DBNull.Value ? null : Convert.ToDateTime(reader["CreatedDate"]),
                    QuantityProduced = reader["QuantityProduced"] == DBNull.Value ? 0 : Convert.ToInt32(reader["QuantityProduced"]),
                    QuantityProductFault = reader["QuantityProductFault"] == DBNull.Value ? 0 : Convert.ToInt32(reader["QuantityProductFault"]),
                    CupNo = reader["CupNo"] == DBNull.Value ? 0 : Convert.ToInt32(reader["CupNo"]),
                    Color = reader["Color"]?.ToString() ?? "",
                    WaterPercent = waterPercent,
                    WeightDifference = weightDifference,
                    RealWeight = realWeight,
                    ErrorPercent = errorPercent,
                    CycleTimeSeconds = CalculateCycleTimeSeconds(timeSpentMinutes)
                });
            }
        }

        private void CalculateSummary()
        {
            TotalOrders = CupRows.Select(x => x.OrderId).Distinct().Count();
            TotalCups = CupRows.Count;

            TotalProduced = CupRows
                .GroupBy(x => x.OrderId)
                .Select(g => g.First().QuantityProduced)
                .Sum();

            TotalFaultProducts = CupRows
                .GroupBy(x => x.OrderId)
                .Select(g => g.First().QuantityProductFault)
                .Sum();

            var cycleRows = CupRows.Where(x => x.CycleTimeSeconds > 0).ToList();
            AvgCycleTime = cycleRows.Count > 0 ? cycleRows.Average(x => x.CycleTimeSeconds) : 0;
            MinCycleTime = cycleRows.Count > 0 ? cycleRows.Min(x => x.CycleTimeSeconds) : 0;
            MaxCycleTime = cycleRows.Count > 0 ? cycleRows.Max(x => x.CycleTimeSeconds) : 0;

            var qualityRows = CupRows.Where(x => x.WeightDifference.HasValue).ToList();
            QualityMeasurementCount = qualityRows.Count;
            AcceptedCount = qualityRows.Count(x => Math.Abs(x.WeightDifference!.Value) <= Tolerance);
            AvgWeightDifference = qualityRows.Count > 0 ? qualityRows.Average(x => x.WeightDifference!.Value) : 0;
            MAE = qualityRows.Count > 0 ? qualityRows.Average(x => Math.Abs(x.WeightDifference!.Value)) : 0;
            MSE = qualityRows.Count > 0 ? qualityRows.Average(x => Math.Pow(x.WeightDifference!.Value, 2)) : 0;
            RMSE = Math.Sqrt(MSE);
            MaxAbsWeightDifference = qualityRows.Count > 0 ? qualityRows.Max(x => Math.Abs(x.WeightDifference!.Value)) : 0;
            AcceptanceRate = QualityMeasurementCount > 0 ? AcceptedCount * 100.0 / QualityMeasurementCount : 0;

            var mapeRows = CupRows.Where(x => x.ErrorPercent.HasValue).ToList();
            MAPE = mapeRows.Count > 0 ? mapeRows.Average(x => x.ErrorPercent!.Value) : 0;
        }

        private void CalculatePhaseComparison()
        {
            PhaseComparisons = CupRows
                .Where(x => !string.IsNullOrWhiteSpace(x.TestPhase))
                .GroupBy(x => x.TestPhase)
                .Select(g =>
                {
                    var qualityRows = g.Where(x => x.WeightDifference.HasValue).ToList();
                    var cycleRows = g.Where(x => x.CycleTimeSeconds > 0).ToList();
                    var mapeRows = g.Where(x => x.ErrorPercent.HasValue).ToList();

                    return new PhaseComparisonRow
                    {
                        TestPhase = g.Key,
                        CupCount = g.Count(),
                        OrderCount = g.Select(x => x.OrderId).Distinct().Count(),
                        AvgCycleTime = cycleRows.Count > 0 ? cycleRows.Average(x => x.CycleTimeSeconds) : 0,
                        MAE = qualityRows.Count > 0 ? qualityRows.Average(x => Math.Abs(x.WeightDifference!.Value)) : 0,
                        MAPE = mapeRows.Count > 0 ? mapeRows.Average(x => x.ErrorPercent!.Value) : 0,
                        AcceptanceRate = qualityRows.Count > 0
                            ? qualityRows.Count(x => Math.Abs(x.WeightDifference!.Value) <= Tolerance) * 100.0 / qualityRows.Count
                            : 0
                    };
                })
                .OrderBy(x => x.TestPhase)
                .ToList();
        }

        private void BuildCharts()
        {
            var cycleRows = CupRows.Where(x => x.CycleTimeSeconds > 0).OrderBy(x => x.OrderId).ThenBy(x => x.CupNo).ToList();

            CycleChartLabels = cycleRows
                .Select(x => $"O{x.OrderId}-K{x.CupNo}")
                .ToList();

            CycleChartValues = cycleRows
                .Select(x => Math.Round(x.CycleTimeSeconds, 2))
                .ToList();

            var errorByCup = CupRows
                .Where(x => x.ErrorPercent.HasValue)
                .GroupBy(x => x.CupNo)
                .OrderBy(g => g.Key)
                .Select(g => new { CupNo = g.Key, Mape = g.Average(x => x.ErrorPercent!.Value) })
                .ToList();

            ErrorByCupChartLabels = errorByCup
                .Select(x => $"Kopp {x.CupNo}")
                .ToList();

            ErrorByCupChartValues = errorByCup
                .Select(x => Math.Round(x.Mape, 2))
                .ToList();
        }

        private static double CalculateCycleTimeSeconds(decimal? timeSpentMinutes)
        {
            if (timeSpentMinutes.HasValue && timeSpentMinutes.Value > 0)
                return (double)timeSpentMinutes.Value * 60.0;

            return 0;
        }

        public class CupAnalysisRow
        {
            public int OrderId { get; set; }
            public string TestPhase { get; set; } = "";
            public DateTime? CreatedDate { get; set; }
            public int QuantityProduced { get; set; }
            public int QuantityProductFault { get; set; }
            public int CupNo { get; set; }
            public string Color { get; set; } = "";
            public double WaterPercent { get; set; }
            public double? WeightDifference { get; set; }
            public double? RealWeight { get; set; }
            public double? ErrorPercent { get; set; }
            public double CycleTimeSeconds { get; set; }

            public string CreatedDateText => CreatedDate?.ToString("dd.MM.yyyy HH:mm:ss") ?? "-";
            public string WeightDifferenceText => WeightDifference.HasValue ? WeightDifference.Value.ToString("N2", CultureInfo.InvariantCulture) : "-";
            public string RealWeightText => RealWeight.HasValue ? RealWeight.Value.ToString("N2", CultureInfo.InvariantCulture) : "-";
            public string ErrorPercentText => ErrorPercent.HasValue ? ErrorPercent.Value.ToString("N2", CultureInfo.InvariantCulture) + "%" : "-";
        }

        public class PhaseComparisonRow
        {
            public string TestPhase { get; set; } = "";
            public int OrderCount { get; set; }
            public int CupCount { get; set; }
            public double AvgCycleTime { get; set; }
            public double MAE { get; set; }
            public double MAPE { get; set; }
            public double AcceptanceRate { get; set; }
        }
    }
}
