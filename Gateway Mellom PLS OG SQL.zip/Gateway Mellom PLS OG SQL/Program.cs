﻿using System;
using System.Threading;
using Microsoft.Data.SqlClient;
using S7.Net;

namespace Gateway
{
    internal class Program
    {
        // ================= PLC (HANDLING) =================
        static readonly string PlcIp = "192.168.0.201";
        static readonly CpuType PlcCpu = CpuType.S71500;
        static readonly short PlcRack = 0;
        static readonly short PlcSlot = 1;

        // ================= PLC (ROBOT QUALITY) =================
        static readonly string RobotPlcIp = "192.168.0.211";
        static readonly CpuType RobotPlcCpu = CpuType.S71500;
        static readonly short RobotPlcRack = 0;
        static readonly short RobotPlcSlot = 1;

        // ================= HANDLING PLC DB =================
        const string DB = "DB5";

        // Handshake bits
        const string NewOrderAddr = DB + ".DBX0.0";
        const string OrderAckAddr = DB + ".DBX0.1";

        // Order data (DB5)
        const string OrderIdAddr = DB + ".DBD2";
        const string RedQtyAddr = DB + ".DBW6";
        const string BlackQtyAddr = DB + ".DBW8";
        const string TotalQtyAddr = DB + ".DBW10";
        const int CupArrayStartDbw = 12;

        // ================= HANDLING SIGNALS =================
        const string StartOrderSignal = "DB15.DBX0.1";
        const string OrderDoneSignal = "M34.2";

        // ================= ROBOT QUALITY DB =================
        const int QualityDbNumber = 15;

        const int QcOrderIdOffset = 0;           // Byte
        const int QcJarIdOffset = 1;             // Byte
        const int QcWeightDifferenceOffset = 2;  // REAL
        const int QcMinutesOffset = 6;           // INT
        const int QcSecondsOffset = 8;           // INT
        const int QcRealWeightOffset = 10;       // REAL

        // ================= ROBOT ToHMI DB (DB22) =================
        const int ToHmiDbNumber = 22;
        const int JarsOkOffset = 2;              // INT, DBW2
        const int JarsFaultyOffset = 4;          // INT, DBW4

        // ================= FINISH DELAY =================
        static readonly TimeSpan FinishDelay = TimeSpan.FromSeconds(2);

        // ================= SQL =================
        static readonly string SqlConnStr =
            "Server=localhost\\SQLEXPRESS;Database=ERP_DB;Trusted_Connection=True;TrustServerCertificate=True;";

        // Edge detection memory
        static bool _lastStartOrder = false;
        static bool _lastOrderDone = false;

        // Current order being handled
        static int? _currentOrderId = null;

        // Delayed finish state
        static int? _finishPendingOrderId = null;
        static DateTime? _finishPendingSince = null;      
        static DateTime? _finishDetectedAt = null;        

        // Last robot values to avoid duplicate writes
        static int _lastQcOrderId = -1;
        static int _lastQcJarId = -1;
        static float _lastQcWeightDifference = float.MinValue;
        static float _lastQcRealWeight = float.MinValue;
        static short _lastQcMinutes = short.MinValue;
        static short _lastQcSeconds = short.MinValue;

        
        static int _lastFaultOrderId = -1;
        static int _lastJarsFaulty = int.MinValue;

        
        static int _lastProducedOrderId = -1;
        static int _lastJarsOk = int.MinValue;

        
        static int _lastDeletedOrderWarned = -1;
         
        static void Main(string[] args)
        {
            Console.WriteLine("=== ERP Gateway ===");
            Console.WriteLine($"Handling PLC: {PlcIp}");
            Console.WriteLine($"Robot PLC:    {RobotPlcIp}");

            using var plc = new Plc(PlcCpu, PlcIp, PlcRack, PlcSlot);
            using var robotPlc = new Plc(RobotPlcCpu, RobotPlcIp, RobotPlcRack, RobotPlcSlot);

            SafeWriteBool(plc, NewOrderAddr, false);
            _currentOrderId = null;

            while (true)
            {
                try
                {
                    EnsurePlcConnected(plc, PlcIp);
                    EnsurePlcConnected(robotPlc, RobotPlcIp);

                    CheckIfKnownOrderWasDeleted();
                    HandleStartAndDoneSignals(plc);
                    HandleRobotQuality(robotPlc);
                    ProcessPendingFinish();
                    HandleNewOrderHandshake(plc);

                    Thread.Sleep(200);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[{Now()}] Gateway error: {ex.Message}");
                    Thread.Sleep(1000);
                }
            }
        }

        // ================= SEND ORDER TO HANDLING PLC =================

        static void HandleNewOrderHandshake(Plc plc)
        {
            if (_currentOrderId != null)
                return;

            if (_finishPendingOrderId != null)
                return;

            var order = GetNextPendingOrder();
            if (order == null)
            {
                SafeWriteBool(plc, NewOrderAddr, false);
                return;
            }

            WriteOrderToPlc(plc, order);

            bool ack = ReadBool(plc, OrderAckAddr);

            if (!ack)
            {
                SafeWriteBool(plc, NewOrderAddr, true);
                Console.WriteLine($"[{Now()}] Sending OrderId={order.OrderId} to PLC... waiting for OrderAck=TRUE");
                return;
            }

            SafeWriteBool(plc, NewOrderAddr, false);
            UpdateOrderStatus(order.OrderId, "Ready");
            _currentOrderId = order.OrderId;

            Console.WriteLine($"[{Now()}] PLC ack received. SQL: Order {order.OrderId} -> Ready");
        }

        // ================= START / DONE SIGNALS =================

        static void HandleStartAndDoneSignals(Plc plc)
        {
            bool startNow = ReadBool(plc, StartOrderSignal);
            bool doneNow = ReadBool(plc, OrderDoneSignal);

            if (startNow && !_lastStartOrder)
            {
                int? id = _currentOrderId ?? FindLatestReadyOrderId() ?? FindLatestRunningOrderId();

                if (id != null)
                {
                    UpdateOrderStatus(id.Value, "Running");
                    SetStartedDateIfNull(id.Value, DateTime.Now);
                    Console.WriteLine($"[{Now()}] SQL: Order {id.Value} -> Running + StartedDate set");
                }
                else
                {
                    Console.WriteLine($"[{Now()}] StartOrder TRUE but no Ready/Running order found.");
                }
            }

            if (doneNow && !_lastOrderDone)
            {
                int? id = _currentOrderId ?? FindLatestRunningOrderId();

                if (id != null)
                {
                    StartPendingFinish(id.Value, DateTime.Now);
                }
                else
                {
                    Console.WriteLine($"[{Now()}] OrderDone TRUE but no Running order found.");
                }
            }

            _lastStartOrder = startNow;
            _lastOrderDone = doneNow;
        }

        static void StartPendingFinish(int orderId, DateTime detectedAt)
        {
            if (_finishPendingOrderId == orderId)
                return;

            _finishPendingOrderId = orderId;
            _finishPendingSince = DateTime.Now;
            _finishDetectedAt = detectedAt;

            Console.WriteLine($"[{Now()}] Order {orderId} marked for finish. Waiting {FinishDelay.TotalSeconds:0} seconds for final PLC updates...");
        }

        static void ProcessPendingFinish()
        {
            if (_finishPendingOrderId == null || _finishPendingSince == null || _finishDetectedAt == null)
                return;

            TimeSpan elapsed = DateTime.Now - _finishPendingSince.Value;
            if (elapsed < FinishDelay)
                return;

            int orderId = _finishPendingOrderId.Value;
            DateTime actualFinishedAt = _finishDetectedAt.Value;

            SetFinishedDateStatusAndTime(orderId, actualFinishedAt);
            Console.WriteLine($"[{Now()}] SQL: Order {orderId} -> Finished + FinishedDate + TimeSpentMinutes (using actual OrderDone time)");

            _finishPendingOrderId = null;
            _finishPendingSince = null;
            _finishDetectedAt = null;
            _currentOrderId = null;
            _lastDeletedOrderWarned = -1;
        }

        // ================= ROBOT QUALITY =================

        static void HandleRobotQuality(Plc robotPlc)
        {
            try
            {
                var qc = ReadRobotQuality(robotPlc);
                if (qc == null)
                    return;

                if (qc.OrderId > 0 && qc.JarId > 0)
                {
                    if (QualityChanged(qc))
                    {
                        UpdateOrderCupQuality(
                            qc.OrderId,
                            qc.JarId,
                            qc.WeightDifference,
                            qc.RealWeight,
                            qc.TimeSpentMinutes);

                        RememberQuality(qc);

                        Console.WriteLine(
                            $"[{Now()}] Robot QC saved -> OrderId={qc.OrderId}, JarId={qc.JarId}, WeightDifference={qc.WeightDifference:0.###}, RealWeight={qc.RealWeight:0.###}, TimeSpentMinutes={qc.TimeSpentMinutes:0.##}");
                    }
                }

                int? activeOrderId = ResolveActiveOrderIdForProductionUpdate(qc.OrderId);

                if (activeOrderId != null)
                {
                    int jarsOk = ReadJarsOk(robotPlc);
                    if (ProducedQuantityChanged(activeOrderId.Value, jarsOk))
                    {
                        UpdateOrderQuantityProduced(activeOrderId.Value, jarsOk);
                        RememberProducedQuantity(activeOrderId.Value, jarsOk);

                        Console.WriteLine(
                            $"[{Now()}] Orders updated -> OrderId={activeOrderId.Value}, QuantityProduced={jarsOk}");
                    }

                    int jarsFaulty = ReadJarsFaulty(robotPlc);
                    if (FaultyQuantityChanged(activeOrderId.Value, jarsFaulty))
                    {
                        UpdateOrderQuantityProductFault(activeOrderId.Value, jarsFaulty);
                        RememberFaultyQuantity(activeOrderId.Value, jarsFaulty);

                        Console.WriteLine(
                            $"[{Now()}] Orders updated -> OrderId={activeOrderId.Value}, QuantityProductFault={jarsFaulty}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[{Now()}] Robot QC read error: {ex.Message}");
            }
        }

        static QualityDto? ReadRobotQuality(Plc robotPlc)
        {
            byte orderId = ReadByteDb(robotPlc, QualityDbNumber, QcOrderIdOffset);
            byte jarId = ReadByteDb(robotPlc, QualityDbNumber, QcJarIdOffset);
            float weightDifference = ReadRealDb(robotPlc, QualityDbNumber, QcWeightDifferenceOffset);
            short minutes = ReadIntDb(robotPlc, QualityDbNumber, QcMinutesOffset);
            short seconds = ReadIntDb(robotPlc, QualityDbNumber, QcSecondsOffset);
            float realWeight = ReadRealDb(robotPlc, QualityDbNumber, QcRealWeightOffset);

            double timeSpentMinutes = minutes + (seconds / 60.0);

            return new QualityDto
            {
                OrderId = orderId,
                JarId = jarId,
                WeightDifference = weightDifference,
                RealWeight = realWeight,
                Minutes = minutes,
                Seconds = seconds,
                TimeSpentMinutes = Math.Round(timeSpentMinutes, 2)
            };
        }

        static int ReadJarsOk(Plc robotPlc)
        {
            return ReadIntDb(robotPlc, ToHmiDbNumber, JarsOkOffset);
        }

        static int ReadJarsFaulty(Plc robotPlc)
        {
            return ReadIntDb(robotPlc, ToHmiDbNumber, JarsFaultyOffset);
        }

        static int? ResolveActiveOrderIdForProductionUpdate(int qcOrderId)
        {
            if (qcOrderId > 0 && IsOrderActiveForCounts(qcOrderId))
                return qcOrderId;

            if (_currentOrderId != null && IsOrderActiveForCounts(_currentOrderId.Value))
                return _currentOrderId.Value;

            if (_finishPendingOrderId != null && IsOrderActiveForCounts(_finishPendingOrderId.Value))
                return _finishPendingOrderId.Value;

            return FindLatestRunningOrderId();
        }

        static bool IsOrderActiveForCounts(int orderId)
        {
            if (_finishPendingOrderId == orderId)
                return true;

            return IsOrderRunning(orderId);
        }

        static bool QualityChanged(QualityDto qc)
        {
            if (qc.OrderId != _lastQcOrderId) return true;
            if (qc.JarId != _lastQcJarId) return true;
            if (Math.Abs(qc.WeightDifference - _lastQcWeightDifference) > 0.0001f) return true;
            if (Math.Abs(qc.RealWeight - _lastQcRealWeight) > 0.0001f) return true;
            if (qc.Minutes != _lastQcMinutes) return true;
            if (qc.Seconds != _lastQcSeconds) return true;
            return false;
        }

        static void RememberQuality(QualityDto qc)
        {
            _lastQcOrderId = qc.OrderId;
            _lastQcJarId = qc.JarId;
            _lastQcWeightDifference = qc.WeightDifference;
            _lastQcRealWeight = qc.RealWeight;
            _lastQcMinutes = qc.Minutes;
            _lastQcSeconds = qc.Seconds;
        }

        static bool FaultyQuantityChanged(int orderId, int jarsFaulty)
        {
            if (orderId != _lastFaultOrderId) return true;
            if (jarsFaulty != _lastJarsFaulty) return true;
            return false;
        }

        static void RememberFaultyQuantity(int orderId, int jarsFaulty)
        {
            _lastFaultOrderId = orderId;
            _lastJarsFaulty = jarsFaulty;
        }

        static bool ProducedQuantityChanged(int orderId, int jarsOk)
        {
            if (orderId != _lastProducedOrderId) return true;
            if (jarsOk != _lastJarsOk) return true;
            return false;
        }

        static void RememberProducedQuantity(int orderId, int jarsOk)
        {
            _lastProducedOrderId = orderId;
            _lastJarsOk = jarsOk;
        }

        // ================= DELETE WARNING =================

        static void CheckIfKnownOrderWasDeleted()
        {
            if (_currentOrderId != null && !OrderExists(_currentOrderId.Value))
            {
                if (_lastDeletedOrderWarned != _currentOrderId.Value)
                {
                    Console.WriteLine($"[{Now()}] WARNING: Order {_currentOrderId.Value} was deleted from SQL.");
                    _lastDeletedOrderWarned = _currentOrderId.Value;
                }

                _currentOrderId = null;
                _finishPendingOrderId = null;
                _finishPendingSince = null;
                _finishDetectedAt = null;
                return;
            }

            if (_finishPendingOrderId != null && !OrderExists(_finishPendingOrderId.Value))
            {
                if (_lastDeletedOrderWarned != _finishPendingOrderId.Value)
                {
                    Console.WriteLine($"[{Now()}] WARNING: Order {_finishPendingOrderId.Value} was deleted from SQL.");
                    _lastDeletedOrderWarned = _finishPendingOrderId.Value;
                }

                _finishPendingOrderId = null;
                _finishPendingSince = null;
                _finishDetectedAt = null;
            }
        }

        // ================= LOAD CUPS =================

        static int[] LoadCupWaterArray(int orderId)
        {
            var cups = new int[12];

            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
SELECT TOP 12 CupNo, Color, WaterPercent
FROM OrderCups
WHERE OrderId = @orderId
ORDER BY
  CASE WHEN Color = 'Red' THEN 0 ELSE 1 END,
  CupNo ASC;", conn);

            cmd.Parameters.AddWithValue("@orderId", orderId);

            using var r = cmd.ExecuteReader();
            int idx = 0;
            while (r.Read() && idx < 12)
            {
                int water = Convert.ToInt32(r["WaterPercent"]);
                cups[idx++] = water;
            }

            return cups;
        }

        // ================= PLC HELPERS =================

        static void EnsurePlcConnected(Plc plc, string ip)
        {
            if (plc.IsConnected)
                return;

            Console.WriteLine($"[{Now()}] Connecting PLC {ip}...");
            plc.Open();

            if (!plc.IsConnected)
                throw new Exception($"PLC not connected: {ip}");

            Console.WriteLine($"[{Now()}] PLC connected: {ip}");
        }

        static bool ReadBool(Plc plc, string addr)
        {
            object? v = plc.Read(addr);
            return v is bool b && b;
        }

        static byte ReadByteDb(Plc plc, int dbNumber, int byteOffset)
        {
            object? value = plc.Read(DataType.DataBlock, dbNumber, byteOffset, VarType.Byte, 1);
            if (value == null) return 0;
            return Convert.ToByte(value);
        }

        static short ReadIntDb(Plc plc, int dbNumber, int byteOffset)
        {
            object? value = plc.Read(DataType.DataBlock, dbNumber, byteOffset, VarType.Int, 1);
            if (value == null) return 0;
            return Convert.ToInt16(value);
        }

        static float ReadRealDb(Plc plc, int dbNumber, int byteOffset)
        {
            object? value = plc.Read(DataType.DataBlock, dbNumber, byteOffset, VarType.Real, 1);
            if (value == null) return 0f;
            return Convert.ToSingle(value);
        }

        static void SafeWriteBool(Plc plc, string addr, bool value)
        {
            try
            {
                if (!plc.IsConnected)
                    plc.Open();

                plc.Write(addr, value);
            }
            catch
            {
            }
        }

        static void WriteOrderToPlc(Plc plc, OrderDto order)
        {
            plc.Write(OrderIdAddr, order.OrderId);
            plc.Write(RedQtyAddr, (short)order.RedQty);
            plc.Write(BlackQtyAddr, (short)order.BlackQty);
            plc.Write(TotalQtyAddr, (short)order.TotalQty);

            for (int i = 0; i < 12; i++)
            {
                int dbw = CupArrayStartDbw + (i * 2);
                plc.Write($"{DB}.DBW{dbw}", (short)order.CupWater[i]);
            }
        }

        // ================= SQL HELPERS =================

        static OrderDto? GetNextPendingOrder()
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
SELECT TOP 1 OrderId, RedQty, BlackQty, TotalQty
FROM Orders
WHERE Status = 'Pending'
ORDER BY OrderId ASC;", conn);

            using var r = cmd.ExecuteReader();
            if (!r.Read())
                return null;

            int orderId = Convert.ToInt32(r["OrderId"]);
            int red = Convert.ToInt32(r["RedQty"]);
            int black = Convert.ToInt32(r["BlackQty"]);
            int total = Convert.ToInt32(r["TotalQty"]);

            int expectedTotal = red + black;
            if (total != expectedTotal)
                total = expectedTotal;

            int[] water = LoadCupWaterArray(orderId);

            return new OrderDto
            {
                OrderId = orderId,
                RedQty = red,
                BlackQty = black,
                TotalQty = total,
                CupWater = water
            };
        }

        static void UpdateOrderStatus(int orderId, string status)
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
UPDATE Orders
SET Status = @status
WHERE OrderId = @id;", conn);

            cmd.Parameters.AddWithValue("@status", status);
            cmd.Parameters.AddWithValue("@id", orderId);

            cmd.ExecuteNonQuery();
        }

        static void UpdateOrderCupQuality(int orderId, int jarId, float weightDifference, float realWeight, double timeSpentMinutes)
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
UPDATE OrderCups
SET WeightDifference = @WeightDifference,
    RealWeight = @RealWeight,
    TimeSpentMinutes = @TimeSpentMinutes
WHERE OrderId = @OrderId
  AND CupNo = @CupNo;", conn);

            cmd.Parameters.AddWithValue("@OrderId", orderId);
            cmd.Parameters.AddWithValue("@CupNo", jarId);
            cmd.Parameters.AddWithValue("@WeightDifference", weightDifference);
            cmd.Parameters.AddWithValue("@RealWeight", realWeight);
            cmd.Parameters.AddWithValue("@TimeSpentMinutes", Math.Round(timeSpentMinutes, 2));

            int rows = cmd.ExecuteNonQuery();

            if (rows == 0)
            {
                Console.WriteLine($"[{Now()}] WARNING: No OrderCups row updated for OrderId={orderId}, CupNo={jarId}");
            }
        }

        static void UpdateOrderQuantityProduced(int orderId, int jarsOk)
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
UPDATE Orders
SET QuantityProduced = @QuantityProduced
WHERE OrderId = @OrderId;", conn);

            cmd.Parameters.AddWithValue("@OrderId", orderId);
            cmd.Parameters.AddWithValue("@QuantityProduced", jarsOk);

            int rows = cmd.ExecuteNonQuery();

            if (rows == 0)
            {
                Console.WriteLine($"[{Now()}] WARNING: No Orders row updated for OrderId={orderId}");
            }
        }

        static void UpdateOrderQuantityProductFault(int orderId, int jarsFaulty)
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
UPDATE Orders
SET QuantityProductFault = @QuantityProductFault
WHERE OrderId = @OrderId;", conn);

            cmd.Parameters.AddWithValue("@OrderId", orderId);
            cmd.Parameters.AddWithValue("@QuantityProductFault", jarsFaulty);

            int rows = cmd.ExecuteNonQuery();

            if (rows == 0)
            {
                Console.WriteLine($"[{Now()}] WARNING: No Orders row updated for OrderId={orderId}");
            }
        }

        static int? FindLatestRunningOrderId()
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
SELECT TOP 1 OrderId
FROM Orders
WHERE Status = 'Running'
  AND FinishedDate IS NULL
ORDER BY COALESCE(StartedDate, CreatedDate) DESC;", conn);

            object? result = cmd.ExecuteScalar();
            if (result == null || result == DBNull.Value)
                return null;

            return Convert.ToInt32(result);
        }

        static int? FindLatestReadyOrderId()
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
SELECT TOP 1 OrderId
FROM Orders
WHERE Status = 'Ready'
  AND FinishedDate IS NULL
ORDER BY CreatedDate DESC;", conn);

            object? result = cmd.ExecuteScalar();
            if (result == null || result == DBNull.Value)
                return null;

            return Convert.ToInt32(result);
        }

        static bool IsOrderRunning(int orderId)
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
SELECT COUNT(1)
FROM Orders
WHERE OrderId = @id
  AND Status = 'Running'
  AND FinishedDate IS NULL;", conn);

            cmd.Parameters.AddWithValue("@id", orderId);

            int count = Convert.ToInt32(cmd.ExecuteScalar());
            return count > 0;
        }

        static void SetStartedDateIfNull(int orderId, DateTime started)
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
UPDATE Orders
SET StartedDate = @dt
WHERE OrderId = @id
  AND StartedDate IS NULL;", conn);

            cmd.Parameters.AddWithValue("@dt", started);
            cmd.Parameters.AddWithValue("@id", orderId);

            cmd.ExecuteNonQuery();
        }

        static void SetFinishedDateStatusAndTime(int orderId, DateTime finished)
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            DateTime? startedDate = null;

            using (var readCmd = new SqlCommand(@"
SELECT StartedDate
FROM Orders
WHERE OrderId = @id;", conn))
            {
                readCmd.Parameters.AddWithValue("@id", orderId);
                object? result = readCmd.ExecuteScalar();

                if (result != null && result != DBNull.Value)
                    startedDate = Convert.ToDateTime(result);
            }

            double? timeSpentMinutes = null;
            if (startedDate != null)
                timeSpentMinutes = Math.Round((finished - startedDate.Value).TotalMinutes, 2);

            using var cmd = new SqlCommand(@"
UPDATE Orders
SET FinishedDate = @dt,
    Status = 'Finished',
    TimeSpentMinutes = @TimeSpentMinutes
WHERE OrderId = @id;", conn);

            cmd.Parameters.AddWithValue("@dt", finished);
            cmd.Parameters.AddWithValue("@id", orderId);
            cmd.Parameters.AddWithValue("@TimeSpentMinutes", (object?)timeSpentMinutes ?? DBNull.Value);

            cmd.ExecuteNonQuery();
        }

        static bool OrderExists(int orderId)
        {
            using var conn = new SqlConnection(SqlConnStr);
            conn.Open();

            using var cmd = new SqlCommand(@"
SELECT COUNT(1)
FROM Orders
WHERE OrderId = @id;", conn);

            cmd.Parameters.AddWithValue("@id", orderId);

            int count = Convert.ToInt32(cmd.ExecuteScalar());
            return count > 0;
        }

        static string Now()
        {
            return DateTime.Now.ToString("HH:mm:ss");
        }

        // ================= DTO =================

        class OrderDto
        {
            public int OrderId { get; set; }
            public int RedQty { get; set; }
            public int BlackQty { get; set; }
            public int TotalQty { get; set; }
            public int[] CupWater { get; set; } = new int[12];
        }

        class QualityDto
        {
            public int OrderId { get; set; }
            public int JarId { get; set; }
            public float WeightDifference { get; set; }
            public float RealWeight { get; set; }
            public short Minutes { get; set; }
            public short Seconds { get; set; }
            public double TimeSpentMinutes { get; set; }
        }
    }
}